/**
 * @Author: Chacha 
 * @Date: 2018-12-25 22:53:20 
 * @Last Modified by: Chacha
 * @Last Modified time: 2018-12-29 23:19:23
 */

#include <iostream>
#include <vector>
using namespace std;

/**
 * Source:
 *  https://zh.wikipedia.org/wiki/归并排序
 *  https://algs4.cs.princeton.edu/22mergesort/ 
 */
int mergeSort(vector<int> &nums) {
    
}

int main() {
    return 0;
}