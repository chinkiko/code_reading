# [24. Swap Nodes in Pairs](https://leetcode.com/problems/swap-nodes-in-pairs/description/)

## 题目

Given a linked list, swap every two adjacent nodes and return its head.

You may not modify the values in the list's nodes, only nodes itself may be changed.



Example:

```c
Given 1->2->3->4, you should return the list as 2->1->4->3.
```

## 题目大意

两两相邻的元素，翻转链表

## 解题思路

按照题意做即可。