// Time Complexity: O(n^2)
// Space Complexity: O(n^2)

class Solution {
    public:      
        int minCut(string s) {
            const int n = s.size();
            vector<vector<bool> > p(n, vector<bool>(n, false)); // p[i][j]: range [i, j] is a palindrome paritioning of s
            vector<int> f(n + 1, 0); // f[i]: minimum cuts in range [i, n - 1]

            for(int i = 0; i <= n; ++i) {
                f[i] = n - 1 - i;    // initialize f[i] to the max cuts
            }

            for (int i = n - 1; i >= 0; --i) {
                for (int j = i; j < n; ++j) {
                    // [i, j] is palindrome if only if s[i] equals to s[j] and [i + 1, j - 1] is palindrome too
                    if(s[i] == s[j] && ((j - i < 2) || p[i + 1][j - 1])) {
                        p[i][j] = true;
                        f[i] = min(f[i], f[j + 1] + 1);  // f[i] = min(f[j + 1] + 1) for each i <= j <= n - 1
                    }
                }   
            }

            return f[0];
        }
};
