// Time Complexity: O(m * n)
// Space Complexity: O(n)

class Solution {
    public:
        int numDistinct(const string &S, const string &T) {
            vector<int> f(T.size() + 1);
            f[0] = 1; // f(0, 0) = 1, means S = "" and T = "", there is only one distinct subsequence, i.e. ""
            for (int i = 1; i <= S.size(); ++i) {
                for (int j = T.size(); j > 0; --j) {
                    // f(i, j) is composed of:
                    // f(i−1,j): not using S[i - 1] 
                    // f(i−1,j−1): using S[i - 1] if S[i - 1] == S[j - 1]
                    f[j] += (S[i - 1] == T[j - 1]) ? f[j - 1] : 0;
                }
            }
            return f[T.size()];
        }
};
